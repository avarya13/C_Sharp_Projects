﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace temp
{
    class Program
    {
        static void Main(string[] args)
        {
            const double xh = 0.2, h = 0.2, eps = 0.0001;
            double a, x, s, y, c;
            int n = 5, i;
            x = xh;
            for (int j = 1; j <= n; j++)
{              
        s = 1; c = -1; i = 1;
                do
                {
                    c = -c * x * x / ((2 * i - 1) * 2 * i);
                    a = c * (2 * i - 1);
                    s = s + a;
                    i = i + 1;
                } while (Math.Abs(a) >= eps);
                y = Math.Cos(x) + x * Math.Sin(x);
                Console.WriteLine(" x = { 0:f4}, s = { 1:f4},y = { 2:f4}",x, s, y);
                x = x + h;
            }
            Console.ReadKey();
        }
    }
}
